import os, sys
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

sys.path.append('../src')

from beaker import benchmark

bm = benchmark.Benchmark()

hostname = os.getenv("DATABRICKS_HOST")
http_path = os.getenv("DATABRICKS_HTTP_PATH")
# Don't put tokens in plaintext in code
access_token = os.getenv("DATABRICKS_ACCESS_TOKEN")

catalog = os.getenv('CATALOG')
schema = os.getenv('SCHEMA')

bm.setName(name="tpcds")
bm.setHostname(hostname=hostname)
bm.setWarehouse(http_path=http_path)
bm.setConcurrency(concurrency=1)
bm.setWarehouseToken(token=access_token)

bm.setCatalog(catalog)
bm.setSchema(schema)

print("---- Specify a query directory ------")
bm.setQueryFileDir('/Users/nishant.deshpande/Downloads/ThroughputTest/queries_10')
metrics = bm.execute()
print(metrics)
