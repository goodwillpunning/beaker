import re
def _get_queries_from_file_format_semi(file_path):
    """
    Parses a SQL file and returns a list of tuples with the query_id and the query text.

    Parameters:
    file_path (str): The path to the SQL file.

    Returns:
    list: A list of tuples, where each tuple contains a query_id and a query text.
    """
    with open(file_path, 'r') as file:
        content = file.read().strip()

    matches = re.findall(r'--\s*(.*?)\s*;', content, re.DOTALL)

    print(matches)

    queries = [query_text.strip() for query_text in matches]

    # queries = [(f"--{query_id}--\n{query_text.strip()};", query_id) for query_id, query_text in matches]
    return queries


queries = _get_queries_from_file_format_semi('../../examples/queries/q1.sql')
print(queries)