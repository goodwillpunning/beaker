-- {"query_id":"q1"}
select 'q1', now();
