-- {"query_id":"q2"}
select 'q2', now();
