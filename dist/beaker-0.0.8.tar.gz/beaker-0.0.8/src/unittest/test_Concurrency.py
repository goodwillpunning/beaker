from databricks import sql
import os
from dotenv import load_dotenv
from concurrent.futures import ThreadPoolExecutor, wait, ALL_COMPLETED
import time
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

load_dotenv()

hostname = os.getenv("DATABRICKS_HOST")
http_path = os.getenv("DATABRICKS_HTTP_PATH")
# # Don't put tokens in plaintext in code
access_token = os.getenv("DATABRICKS_ACCESS_TOKEN")
catalog_name = os.getenv("CATALOG")
schema_name = os.getenv("SCHEMA")

from datetime import datetime


def execute_query(query_str):
    print(f"Executing query {datetime.now()}")
    with sql.connect(server_hostname = f"https://{hostname}",
                    http_path       = http_path,
                    access_token    = access_token,
                    session_configuration = {"use_cached_result": "false"}) as connection:
        logging.info(f"Created new connection: {connection}")
        with connection.cursor() as cursor:
            cursor.execute(query_str)
            # result = cursor.fetchall()

def execute_single_query(query):
      start_time = time.perf_counter()
      result = execute_query(query)
      end_time = time.perf_counter()
      elapsed_time = f"{end_time - start_time:0.3f}"

      metrics = {
          "id": id,
          "hostname": hostname,
          "query": query,
          "elapsed_time": elapsed_time,
      }
      return metrics

def logged_execute_single_query(query_str):
    logging.info("Starting query")
    result = execute_single_query(query_str)
    logging.info("Finished query")
    return result

query_str = """
  SELECT count(*)
    FROM delta.`/databricks-datasets/nyctaxi/tables/nyctaxi_yellow`
  WHERE passenger_count > 2;
  """


queries = [query_str]*8
# print(len(queries))

with ThreadPoolExecutor(max_workers=4) as executor:
    futures = [executor.submit(logged_execute_single_query, query_str) for query_str in queries]
    wait(futures, return_when=ALL_COMPLETED)
results = [future.result() for future in futures]
# print(results)
# _execute_single_query(query_str)